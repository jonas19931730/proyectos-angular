

export interface Auth {
    id:      string;
    email:   string;
    usuario: string;
}